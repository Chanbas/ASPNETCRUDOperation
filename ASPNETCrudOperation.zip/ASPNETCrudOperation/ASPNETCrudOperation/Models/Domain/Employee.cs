﻿using Microsoft.EntityFrameworkCore;

namespace ASPNETCrudOperation.Models.Domain
{
    [Keyless]
    public class Employee
    {
        
        public Guid ProductId { get; set; }
        public string ProductName { get; set; }
        public long CategoryID { get; set; }
        public string CategoryName { get; set; } 
    }
}
