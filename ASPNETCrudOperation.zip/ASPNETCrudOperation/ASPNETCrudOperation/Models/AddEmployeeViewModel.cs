﻿namespace ASPNETCrudOperation.Models
{
    public class AddEmployeeViewModel
    {
        public string ProductName { get; set; }
        public long CategoryID { get; set; }
        public string CategoryName { get; set; }
    }
}

