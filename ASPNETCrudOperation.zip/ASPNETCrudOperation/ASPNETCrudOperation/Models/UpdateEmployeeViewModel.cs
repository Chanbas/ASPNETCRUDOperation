﻿namespace ASPNETCrudOperation.Models
{
	public class UpdateEmployeeViewModel
	{
		public Guid ProductId { get; set; }
		public string ProductName { get; set; }
		public long CategoryId { get; set; }
        public long CategoryID { get; internal set; }
        public string CategoryName { get; set; }
	}
}
