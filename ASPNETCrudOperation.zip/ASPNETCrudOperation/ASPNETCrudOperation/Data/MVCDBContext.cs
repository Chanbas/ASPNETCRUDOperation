﻿using ASPNETCrudOperation.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace ASPNETCrudOperation.Data
{
    public class MVCDBContext:DbContext
    {
        public MVCDBContext(DbContextOptions options) : base(options)
        { 
        }

        public DbSet<Employee> Employees { get; set; }
    }
}
