﻿using ASPNETCrudOperation.Data;
using ASPNETCrudOperation.Models;
using ASPNETCrudOperation.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ASPNETCrudOperation.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly MVCDBContext mvcDBContext;

        public EmployeeController(MVCDBContext mvcDBContext)
        {
            this.mvcDBContext = mvcDBContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
           var employees = await mvcDBContext.Employees.ToListAsync();
            return View(employees);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddEmployeeViewModel addEmployeeRequest)
        {
            var employee = new Employee()
            {
                ProductId = Guid.NewGuid(),
                ProductName = addEmployeeRequest.ProductName,
                CategoryID = addEmployeeRequest.CategoryID,
                CategoryName = addEmployeeRequest.CategoryName
            };

            await mvcDBContext.Employees.AddAsync(employee);
            await mvcDBContext.SaveChangesAsync();
            return RedirectToAction("Add");
        }

        [HttpGet]
		public async Task<IActionResult> View(Guid productid)
		{
           var employee = await mvcDBContext.Employees.FirstOrDefaultAsync(x => x.ProductId == productid);

            if(employee != null)
            {
                var viewModel = new UpdateEmployeeViewModel()
                {
                    ProductId = employee.ProductId,
                    ProductName = employee.ProductName,
                    CategoryId = employee.CategoryID,
                    CategoryName = employee.CategoryName
                };
                return await Task.Run(() => View("View",viewModel));
            }  

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> View(UpdateEmployeeViewModel model)
        {
            var employee = await mvcDBContext.Employees.FindAsync(model.ProductId);

            if (employee != null)
            {
                employee.ProductName = model.ProductName;
                employee.CategoryID = model.CategoryID;
                employee.CategoryName = model.CategoryName;

                 await mvcDBContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateEmployeeViewModel model)
        {
            var employee = await mvcDBContext.Employees.FindAsync(model.ProductId);

            if(employee != null)
            {
                mvcDBContext.Employees.Remove(employee);
                await mvcDBContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}
